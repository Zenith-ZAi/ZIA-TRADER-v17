
import logging

logger = logging.getLogger("audit")

class AuditService:

    @staticmethod
    async def log_trade_execution(symbol, action, quantity, price):
        logger.info(
            f"[TRADE] {symbol} | {action} | qty={quantity} | price={price}"
        )

    @staticmethod
    async def log_error(error):
        logger.error(f"[ERROR] {error}")
