
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from models.trade import Trade

class TradeRepository:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_trade(self, trade: Trade):
        self.db.add(trade)
        await self.db.flush()
        await self.db.refresh(trade)
        return trade

    async def get_open_trades(self):
        query = select(Trade).where(Trade.status == "open")
        result = await self.db.execute(query)
        return result.scalars().all()
