"""
data/market_data_feeds.py

Camada unificada de feeds de dados de mercado em tempo real.
Integra: Binance WebSocket, Polygon.io, Finnhub, Alpha Vantage.

PROBLEMA IDENTIFICADO NO CORE:
  engine.py busca dados via HTTP polling (get_historical_data a cada 60s).
  Isso é lento demais para trading — latência de 1-3s por ciclo.
  Esta camada adiciona WebSocket streams para dados em tempo real.
"""

import asyncio
import json
import logging
import time
from typing import Dict, Any, Optional, Callable, List
from datetime import datetime

import aiohttp

from config.settings import Settings

logger = logging.getLogger(__name__)


# ─── Polygon.io — Ações, Opções, Forex ────────────────────────────────────────

class PolygonFeed:
    """
    Dados em tempo real via Polygon.io.
    Cobre: ações US, opções, forex, crypto.
    Plano Starter ($29/mês) já inclui dados com 15min delay.
    Plano Starter+ ($79/mês) inclui real-time.
    """

    BASE_REST  = "https://api.polygon.io"
    BASE_WS    = "wss://socket.polygon.io"

    def __init__(self, api_key: str):
        self.api_key  = api_key
        self.session: Optional[aiohttp.ClientSession] = None
        self._ws      = None
        self._callbacks: Dict[str, List[Callable]] = {}

    async def _get_session(self) -> aiohttp.ClientSession:
        if not self.session or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session

    # ── REST: snapshot de preço atual ────────────────────────────────────────

    async def get_ticker_snapshot(self, ticker: str) -> Optional[Dict]:
        """Retorna snapshot atual de um ticker (ação ou crypto)."""
        # Crypto: usa endpoint diferente de ações
        if "/" in ticker:
            # Ex: BTC/USDT → X:BTCUSD no Polygon
            poly_ticker = "X:" + ticker.replace("/", "").replace("USDT", "USD")
        else:
            poly_ticker = ticker

        url = f"{self.BASE_REST}/v2/snapshot/locale/us/markets/stocks/tickers/{poly_ticker}"
        session = await self._get_session()
        try:
            async with session.get(url, params={"apiKey": self.api_key}) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    snap = data.get("ticker", {})
                    day  = snap.get("day", {})
                    return {
                        "ticker":     poly_ticker,
                        "last":       snap.get("lastTrade", {}).get("p"),
                        "open":       day.get("o"),
                        "high":       day.get("h"),
                        "low":        day.get("l"),
                        "close":      day.get("c"),
                        "volume":     day.get("v"),
                        "change_pct": snap.get("todaysChangePerc"),
                        "source":     "polygon"
                    }
        except Exception as e:
            logger.error(f"Polygon snapshot error ({ticker}): {e}")
        return None

    async def get_aggregates(
        self, ticker: str, multiplier: int = 1,
        timespan: str = "hour", from_date: str = "2024-01-01",
        to_date: str = None, limit: int = 120
    ) -> List[Dict]:
        """
        Busca barras OHLCV históricas.
        timespan: minute | hour | day | week | month
        """
        import pandas as pd
        if to_date is None:
            to_date = datetime.utcnow().strftime("%Y-%m-%d")

        if "/" in ticker:
            ticker = "X:" + ticker.replace("/", "").replace("USDT", "USD")

        url = f"{self.BASE_REST}/v2/aggs/ticker/{ticker}/range/{multiplier}/{timespan}/{from_date}/{to_date}"
        session = await self._get_session()
        try:
            async with session.get(url, params={"apiKey": self.api_key, "limit": limit, "adjusted": "true"}) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    results = data.get("results", [])
                    logger.info(f"Polygon aggregates: {len(results)} barras para {ticker}")
                    return results
        except Exception as e:
            logger.error(f"Polygon aggregates error ({ticker}): {e}")
        return []

    async def get_options_chain(self, underlying: str, expiry_date: str = None) -> List[Dict]:
        """Busca cadeia de opções de um ativo subjacente."""
        params = {
            "apiKey":            self.api_key,
            "underlying_ticker": underlying,
            "limit":             100,
            "sort":              "strike_price"
        }
        if expiry_date:
            params["expiration_date"] = expiry_date

        url = f"{self.BASE_REST}/v3/reference/options/contracts"
        session = await self._get_session()
        try:
            async with session.get(url, params=params) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    contracts = data.get("results", [])
                    logger.info(f"Polygon options chain: {len(contracts)} contratos para {underlying}")
                    return contracts
        except Exception as e:
            logger.error(f"Polygon options error ({underlying}): {e}")
        return []

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()


# ─── Finnhub — Notícias, Sentimento, Fundamentals ────────────────────────────

class FinnhubFeed:
    """
    Finnhub.io — notícias em tempo real, sentimento social,
    calendário econômico, earnings, insider trades.
    Plano gratuito: 60 req/min.
    """

    BASE_REST = "https://finnhub.io/api/v1"

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.session: Optional[aiohttp.ClientSession] = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if not self.session or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session

    async def get_company_news(self, symbol: str, from_date: str, to_date: str) -> List[Dict]:
        """Notícias recentes de uma empresa específica."""
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.BASE_REST}/company-news",
                params={"symbol": symbol, "from": from_date, "to": to_date, "token": self.api_key}
            ) as resp:
                if resp.status == 200:
                    articles = await resp.json()
                    logger.info(f"Finnhub: {len(articles)} notícias para {symbol}")
                    return articles
        except Exception as e:
            logger.error(f"Finnhub news error ({symbol}): {e}")
        return []

    async def get_market_news(self, category: str = "crypto") -> List[Dict]:
        """
        Notícias gerais de mercado.
        category: general | forex | crypto | merger
        """
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.BASE_REST}/news",
                params={"category": category, "token": self.api_key}
            ) as resp:
                if resp.status == 200:
                    articles = await resp.json()
                    logger.info(f"Finnhub market news ({category}): {len(articles)} artigos")
                    return articles
        except Exception as e:
            logger.error(f"Finnhub market news error: {e}")
        return []

    async def get_sentiment(self, symbol: str) -> Dict:
        """Score de sentimento social (Reddit, Twitter) para um ativo."""
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.BASE_REST}/news-sentiment",
                params={"symbol": symbol, "token": self.api_key}
            ) as resp:
                if resp.status == 200:
                    return await resp.json()
        except Exception as e:
            logger.error(f"Finnhub sentiment error ({symbol}): {e}")
        return {}

    async def get_economic_calendar(self) -> List[Dict]:
        """Calendário de eventos econômicos (impacto no mercado)."""
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.BASE_REST}/calendar/economic",
                params={"token": self.api_key}
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("economicCalendar", [])
        except Exception as e:
            logger.error(f"Finnhub calendar error: {e}")
        return []

    async def get_quote(self, symbol: str) -> Optional[Dict]:
        """Quote em tempo real de ação ou índice."""
        session = await self._get_session()
        try:
            async with session.get(
                f"{self.BASE_REST}/quote",
                params={"symbol": symbol, "token": self.api_key}
            ) as resp:
                if resp.status == 200:
                    q = await resp.json()
                    return {
                        "symbol":     symbol,
                        "last":       q.get("c"),
                        "open":       q.get("o"),
                        "high":       q.get("h"),
                        "low":        q.get("l"),
                        "prev_close": q.get("pc"),
                        "change_pct": round(((q.get("c", 0) - q.get("pc", 1)) / q.get("pc", 1)) * 100, 2),
                        "source":     "finnhub"
                    }
        except Exception as e:
            logger.error(f"Finnhub quote error ({symbol}): {e}")
        return None

    async def close(self):
        if self.session and not self.session.closed:
            await self.session.close()


# ─── Binance WebSocket — Crypto em Tempo Real ────────────────────────────────

class BinanceWSFeed:
    """
    Stream WebSocket da Binance para dados de crypto em tempo real.
    Sem necessidade de API Key para dados públicos.
    Latência média: 50-200ms.
    """

    BASE_WS = "wss://stream.binance.com:9443/ws"

    def __init__(self):
        self._price_cache: Dict[str, float] = {}
        self._kline_cache: Dict[str, Dict]  = {}
        self._running = False
        self._tasks: List[asyncio.Task] = []

    def get_cached_price(self, symbol: str) -> Optional[float]:
        """Retorna o último preço do cache (atualizado pelo WebSocket)."""
        key = symbol.replace("/", "").lower()
        return self._price_cache.get(key)

    def get_cached_kline(self, symbol: str) -> Optional[Dict]:
        """Retorna a última vela do cache."""
        key = symbol.replace("/", "").lower()
        return self._kline_cache.get(key)

    async def subscribe_ticker(self, symbol: str, on_tick: Optional[Callable] = None):
        """
        Abre stream de ticker em tempo real para um símbolo.
        Chama on_tick(price, data) a cada atualização.
        """
        stream = symbol.replace("/", "").lower() + "@ticker"
        url    = f"{self.BASE_WS}/{stream}"
        self._running = True

        async def _run():
            while self._running:
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.ws_connect(url) as ws:
                            logger.info(f"Binance WS conectado: {stream}")
                            async for msg in ws:
                                if msg.type == aiohttp.WSMsgType.TEXT:
                                    data  = json.loads(msg.data)
                                    price = float(data.get("c", 0))
                                    key   = symbol.replace("/", "").lower()
                                    self._price_cache[key] = price
                                    if on_tick:
                                        await on_tick(price, data)
                except Exception as e:
                    logger.error(f"Binance WS error ({stream}): {e} — reconectando em 5s")
                    await asyncio.sleep(5)

        task = asyncio.create_task(_run())
        self._tasks.append(task)
        return task

    async def subscribe_klines(self, symbol: str, interval: str = "1m", on_kline: Optional[Callable] = None):
        """
        Stream de velas (klines) em tempo real.
        interval: 1m | 5m | 15m | 1h | 4h | 1d
        """
        stream = symbol.replace("/", "").lower() + f"@kline_{interval}"
        url    = f"{self.BASE_WS}/{stream}"
        self._running = True

        async def _run():
            while self._running:
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.ws_connect(url) as ws:
                            logger.info(f"Binance Kline WS conectado: {stream}")
                            async for msg in ws:
                                if msg.type == aiohttp.WSMsgType.TEXT:
                                    data  = json.loads(msg.data)
                                    kline = data.get("k", {})
                                    key   = symbol.replace("/", "").lower()
                                    self._kline_cache[key] = {
                                        "open":   float(kline.get("o", 0)),
                                        "high":   float(kline.get("h", 0)),
                                        "low":    float(kline.get("l", 0)),
                                        "close":  float(kline.get("c", 0)),
                                        "volume": float(kline.get("v", 0)),
                                        "closed": kline.get("x", False),  # True = vela fechada
                                        "time":   kline.get("t")
                                    }
                                    if on_kline:
                                        await on_kline(self._kline_cache[key])
                except Exception as e:
                    logger.error(f"Binance Kline WS error ({stream}): {e} — reconectando em 5s")
                    await asyncio.sleep(5)

        task = asyncio.create_task(_run())
        self._tasks.append(task)
        return task

    async def stop(self):
        self._running = False
        for task in self._tasks:
            task.cancel()
        self._tasks.clear()
        logger.info("Binance WS feeds encerrados.")


# ─── Agregador Principal ──────────────────────────────────────────────────────

class MarketDataAggregator:
    """
    Agrega todas as fontes de dados em uma interface unificada.
    Integra ao ExchangeConnector e NewsProcessor existentes.

    Hierarquia de dados:
      1. Binance WS   → crypto preço ao vivo (< 200ms)
      2. Polygon      → ações, opções, forex, crypto histórico
      3. Finnhub      → notícias, sentimento, calendário econômico
      4. CCXT (existente) → execução de ordens, balanço
    """

    def __init__(self, settings: Settings):
        self.settings = settings

        self.binance_ws = BinanceWSFeed()

        self.polygon = PolygonFeed(settings.POLYGON_API_KEY) \
            if getattr(settings, "POLYGON_API_KEY", None) else None

        self.finnhub = FinnhubFeed(settings.FINNHUB_API_KEY) \
            if getattr(settings, "FINNHUB_API_KEY", None) else None

        self._started = False

    async def start(self, symbols: List[str]):
        """
        Inicia todos os streams em background para os símbolos configurados.
        Chamado pelo TradingManager no startup.
        """
        if self._started:
            return
        self._started = True

        for symbol in symbols:
            market = self._detect_market(symbol)
            if market == "crypto":
                await self.binance_ws.subscribe_ticker(symbol)
                await self.binance_ws.subscribe_klines(symbol, self.settings.TIMEFRAME)
                logger.info(f"✅ Binance WS stream iniciado: {symbol}")

        logger.info(f"✅ MarketDataAggregator iniciado para {len(symbols)} símbolos")

    async def get_price(self, symbol: str) -> Optional[float]:
        """
        Retorna o preço mais atual disponível.
        Prioridade: Binance WS cache → Polygon REST → Finnhub REST
        """
        market = self._detect_market(symbol)

        # 1. Crypto — cache do WebSocket (latência ~200ms)
        if market == "crypto":
            cached = self.binance_ws.get_cached_price(symbol)
            if cached:
                return cached

        # 2. Ação/índice — Finnhub quote (latência ~500ms)
        if self.finnhub and market in ("stock", "index"):
            quote = await self.finnhub.get_quote(symbol)
            if quote:
                return quote.get("last")

        # 3. Polygon snapshot
        if self.polygon:
            snap = await self.polygon.get_ticker_snapshot(symbol)
            if snap:
                return snap.get("last")

        return None

    async def get_news_with_sentiment(self, symbol: str) -> Dict:
        """
        Agrega notícias do Finnhub + Alpha Vantage com score de sentimento.
        Resolve o problema do NewsProcessor atual que não tem get_latest_news().
        """
        articles  = []
        sentiment = 0.0

        today     = datetime.utcnow().strftime("%Y-%m-%d")
        week_ago  = (datetime.utcnow() - __import__("datetime").timedelta(days=7)).strftime("%Y-%m-%d")

        # Finnhub
        if self.finnhub:
            # Crypto: usa market news; ações: usa company news
            market = self._detect_market(symbol)
            if market == "crypto":
                raw = await self.finnhub.get_market_news("crypto")
            else:
                clean = symbol.replace("/USDT", "").replace("/USD", "")
                raw   = await self.finnhub.get_company_news(clean, week_ago, today)

            for art in raw[:10]:
                articles.append({
                    "title":     art.get("headline", art.get("title", "")),
                    "source":    art.get("source", "finnhub"),
                    "url":       art.get("url", ""),
                    "sentiment": 0.0   # Finnhub free não inclui score por artigo
                })

            # Score de sentimento agregado do Finnhub
            clean    = symbol.replace("/USDT", "").replace("/USD", "")
            sent_raw = await self.finnhub.get_sentiment(clean)
            sentiment = sent_raw.get("companyNewsScore", 0.0)

        return {
            "symbol":          symbol,
            "sentiment_score": round(sentiment, 4),
            "articles":        articles,
            "count":           len(articles),
            "timestamp":       datetime.utcnow().isoformat()
        }

    async def get_economic_events_today(self) -> List[Dict]:
        """Retorna eventos de alto impacto do dia (para o RiskAI bloquear trades)."""
        if not self.finnhub:
            return []
        events = await self.finnhub.get_economic_calendar()
        high_impact = [e for e in events if e.get("impact", "") == "high"]
        logger.info(f"Eventos econômicos de alto impacto hoje: {len(high_impact)}")
        return high_impact

    def _detect_market(self, symbol: str) -> str:
        if any(c in symbol for c in ["USDT", "BTC", "ETH", "BNB"]):
            return "crypto"
        if any(p in symbol for p in ["EUR", "GBP", "JPY", "CHF"]):
            return "forex"
        if any(i in symbol for i in ["SPX", "NDX", "DJI", "VIX"]):
            return "index"
        return "stock"

    async def stop(self):
        await self.binance_ws.stop()
        if self.polygon:
            await self.polygon.close()
        if self.finnhub:
            await self.finnhub.close()
        logger.info("MarketDataAggregator encerrado.")
