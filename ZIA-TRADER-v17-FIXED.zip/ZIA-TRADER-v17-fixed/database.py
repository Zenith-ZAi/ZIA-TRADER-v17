"""
database.py — CORRIGIDO: migrado para SQLAlchemy async (asyncpg)
compatível com FastAPI assíncrono e PostgreSQL em produção.
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text
from sqlalchemy.orm import declarative_base
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from config.settings import settings
import logging

logger = logging.getLogger(__name__)

Base = declarative_base()

# ─── Modelos ────────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"
    id              = Column(Integer, primary_key=True, index=True)
    username        = Column(String(100), unique=True, index=True, nullable=False)
    email           = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active       = Column(Boolean, default=True)
    created_at      = Column(DateTime, default=datetime.utcnow)

class Trade(Base):
    __tablename__ = "trades"
    id         = Column(Integer, primary_key=True, index=True)
    symbol     = Column(String(20), index=True, nullable=False)
    action     = Column(String(10), nullable=False)   # buy | sell
    quantity   = Column(Float, nullable=False)
    price      = Column(Float, nullable=False)
    stop_loss  = Column(Float)
    take_profit= Column(Float)
    pnl        = Column(Float, default=0.0)
    status     = Column(String(20), default="open")   # open | closed | cancelled
    strategy   = Column(String(100))
    timestamp  = Column(DateTime, default=datetime.utcnow, index=True)

class NewsArticle(Base):
    __tablename__ = "news_articles"
    id              = Column(Integer, primary_key=True, index=True)
    symbol          = Column(String(20), index=True)
    title           = Column(String(500), nullable=False)
    content         = Column(Text)
    sentiment_score = Column(Float)
    source          = Column(String(100))
    url             = Column(String(1000))
    published_at    = Column(DateTime, index=True)

class PerformanceLog(Base):
    """Tabela nova: registra métricas de performance para o loop de aprendizado."""
    __tablename__ = "performance_logs"
    id              = Column(Integer, primary_key=True, index=True)
    date            = Column(DateTime, default=datetime.utcnow, index=True)
    total_trades    = Column(Integer, default=0)
    winning_trades  = Column(Integer, default=0)
    losing_trades   = Column(Integer, default=0)
    win_rate        = Column(Float, default=0.0)
    total_pnl       = Column(Float, default=0.0)
    max_drawdown    = Column(Float, default=0.0)
    best_symbol     = Column(String(20))
    notes           = Column(Text)

# ─── Engine Async ────────────────────────────────────────────────────────────

def _build_async_url(url: str) -> str:
    """Converte URL síncrona para URL asyncpg automaticamente."""
    if url.startswith("postgresql://"):
        return url.replace("postgresql://", "postgresql+asyncpg://", 1)
    if url.startswith("postgres://"):
        return url.replace("postgres://", "postgresql+asyncpg://", 1)
    return url

ASYNC_DATABASE_URL = _build_async_url(settings.DATABASE_URL)

engine = create_async_engine(
    ASYNC_DATABASE_URL,
    echo=False,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,    # verifica conexão antes de usar
)

AsyncSessionLocal = sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

# ─── Funções utilitárias ──────────────────────────────────────────────────────

async def init_db():
    """Cria todas as tabelas no banco de dados."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✅ Banco de dados PostgreSQL inicializado com sucesso.")

async def get_db():
    """Dependency injection para FastAPI — fornece sessão async."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
