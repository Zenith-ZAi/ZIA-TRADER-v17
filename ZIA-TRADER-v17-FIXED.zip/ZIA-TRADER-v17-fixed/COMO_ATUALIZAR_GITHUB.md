# 🚀 Como Atualizar Seu Repositório no GitHub

## Passo 1 — Substitua os arquivos no seu computador

Descompacte o ZIP recebido e copie os arquivos corrigidos
para dentro da pasta do seu projeto local (onde está o clone do GitHub).

Os arquivos que foram modificados/criados:
- `database.py`              ← reescrito (async)
- `requirements.txt`         ← corrigido e completo
- `docker-compose.yml`       ← reescrito (com PostgreSQL)
- `Dockerfile`               ← CMD corrigido
- `config/settings.py`       ← adicionados settings do Sniper
- `ai/whale_detector.py`     ← construtor corrigido
- `core/engine.py`           ← execução real via exchange
- `risk/risk_ai.py`          ← filtro de vela corrigido
- `execution/exchange_connector.py` ← get_historical_data implementado
- `.gitignore`               ← .env.production protegido
- `.env.example`             ← template limpo sem segredos
- `deploy.sh`                ← script de deploy automático (NOVO)

---

## Passo 2 — Abra o terminal na pasta do projeto

```bash
cd /caminho/para/ZIA-TRADER-v17
```

---

## Passo 3 — Verifique o que mudou

```bash
git status
git diff --name-only
```

---

## Passo 4 — Remova o .env.production do histórico do Git (SEGURANÇA)

Se o arquivo foi commitado antes, execute:

```bash
git rm --cached .env.production 2>/dev/null || true
git rm --cached .env 2>/dev/null || true
```

---

## Passo 5 — Faça o commit das correções

```bash
git add .
git commit -m "fix: corrige bugs críticos para deploy v17

- Corrige WhaleDetector.__init__ para aceitar settings opcional
- Corrige Dockerfile CMD para python main.py
- Adiciona PostgreSQL ao docker-compose.yml
- Adiciona settings ausentes do SniperEngine
- Implementa get_historical_data no ExchangeConnector
- Conecta ExecutionEngine à ExchangeConnector real
- Corrige filtro candle_pattern no RiskAI
- Migra database.py para SQLAlchemy async (asyncpg)
- Corrige e completa requirements.txt
- Protege .env.production no .gitignore
- Adiciona script deploy.sh automático"
```

---

## Passo 6 — Envie para o GitHub

```bash
git push origin main
```

Se o branch principal for `master`:
```bash
git push origin master
```

---

## Passo 7 — Deploy no VPS

No seu servidor VPS, execute:

```bash
# Clone o repositório (primeira vez)
git clone https://github.com/Zenith-ZAi/ZIA-TRADER-v17.git
cd ZIA-TRADER-v17

# Ou atualize (se já clonado)
git pull origin main

# Configure as variáveis de ambiente
cp .env.example .env
nano .env   # preencha suas chaves reais

# Execute o deploy automático
chmod +x deploy.sh
./deploy.sh
```

---

## ✅ Verificação final

Após o deploy, confirme que tudo está rodando:

```bash
docker-compose ps        # todos os serviços Up
docker-compose logs -f zia-app   # logs em tempo real
```

---

## 🆘 Se der erro

```bash
docker-compose logs --tail=100   # ver últimas 100 linhas de log
docker-compose down && ./deploy.sh   # reiniciar tudo
```
