"""
infra/redis_cache.py — CORRIGIDO
Problema original: __init__ sem parâmetro URL — quebrava TradingManager.
Também: cliente síncrono usado em contexto async — corrigido com aioredis.
"""
import json
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

class RedisCache:
    """Cache Redis assíncrono para estado em tempo real."""

    def __init__(self, redis_url: str = "redis://localhost:6379/0"):
        self.redis_url = redis_url
        self._client = None   # inicializado em connect()

    async def connect(self):
        """Conecta ao Redis de forma assíncrona. Chamado no startup."""
        try:
            import redis.asyncio as aioredis
            self._client = await aioredis.from_url(
                self.redis_url,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5,
            )
            await self._client.ping()
            logger.info(f"✅ Redis conectado: {self.redis_url}")
        except Exception as e:
            logger.warning(f"⚠️  Redis indisponível ({e}) — cache desativado, sistema continua sem cache.")
            self._client = None

    async def disconnect(self):
        if self._client:
            await self._client.aclose()
            self._client = None

    # ── Operações de estado ────────────────────────────────────────

    async def set_state(self, key: str, value: Any, expire: int = 3600) -> bool:
        if not self._client:
            return False
        try:
            await self._client.set(key, json.dumps(value), ex=expire)
            return True
        except Exception as e:
            logger.error(f"Redis set_state error ({key}): {e}")
            return False

    async def get_state(self, key: str) -> Optional[Any]:
        if not self._client:
            return None
        try:
            data = await self._client.get(key)
            return json.loads(data) if data else None
        except Exception as e:
            logger.error(f"Redis get_state error ({key}): {e}")
            return None

    async def delete(self, key: str) -> bool:
        if not self._client:
            return False
        try:
            await self._client.delete(key)
            return True
        except Exception as e:
            logger.error(f"Redis delete error ({key}): {e}")
            return False

    # ── Preços em tempo real ───────────────────────────────────────

    async def update_price(self, symbol: str, price: float, expire: int = 60):
        if not self._client:
            return
        try:
            key = f"price:{symbol.replace('/', '_')}"
            await self._client.set(key, str(price), ex=expire)
        except Exception as e:
            logger.error(f"Redis update_price error: {e}")

    async def get_price(self, symbol: str) -> Optional[float]:
        if not self._client:
            return None
        try:
            key = f"price:{symbol.replace('/', '_')}"
            val = await self._client.get(key)
            return float(val) if val else None
        except Exception as e:
            logger.error(f"Redis get_price error: {e}")
            return None

    # ── Métricas de performance ────────────────────────────────────

    async def save_performance(self, metrics: dict, expire: int = 86400):
        """Salva métricas de performance para o loop de aprendizado."""
        await self.set_state("performance:latest", metrics, expire)

    async def get_performance(self) -> Optional[dict]:
        return await self.get_state("performance:latest")

    # ── Compatibilidade síncrona (fallback para código legado) ─────

    def set_state_sync(self, key: str, value: Any, expire: int = 3600):
        """Versão síncrona — use apenas fora de contexto async."""
        try:
            import redis as sync_redis
            client = sync_redis.from_url(self.redis_url, decode_responses=True)
            client.set(key, json.dumps(value), ex=expire)
            client.close()
        except Exception as e:
            logger.warning(f"Redis sync set_state error: {e}")
