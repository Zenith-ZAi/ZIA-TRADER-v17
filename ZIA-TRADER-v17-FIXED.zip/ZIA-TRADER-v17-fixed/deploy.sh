#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# ZIA TRADER v17 — Script de Deploy para VPS
# Execute: chmod +x deploy.sh && ./deploy.sh
# ─────────────────────────────────────────────────────────────────

set -e  # Para em qualquer erro

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}🚀 Iniciando deploy do ZIA TRADER v17...${NC}"

# 1. Verificar dependências
echo -e "${YELLOW}[1/6] Verificando dependências...${NC}"
command -v docker >/dev/null 2>&1 || { echo -e "${RED}Docker não encontrado. Instale: https://docs.docker.com/engine/install/${NC}"; exit 1; }
command -v docker-compose >/dev/null 2>&1 || { echo -e "${RED}Docker Compose não encontrado.${NC}"; exit 1; }

# 2. Verificar arquivo .env
echo -e "${YELLOW}[2/6] Verificando configuração...${NC}"
if [ ! -f ".env" ]; then
    echo -e "${RED}Arquivo .env não encontrado!${NC}"
    echo "Copie o .env.example e preencha suas chaves:"
    echo "  cp .env.example .env && nano .env"
    exit 1
fi

# 3. Build da imagem
echo -e "${YELLOW}[3/6] Fazendo build da imagem Docker...${NC}"
docker-compose build --no-cache

# 4. Parar containers antigos
echo -e "${YELLOW}[4/6] Parando containers anteriores...${NC}"
docker-compose down --remove-orphans 2>/dev/null || true

# 5. Subir serviços
echo -e "${YELLOW}[5/6] Iniciando todos os serviços...${NC}"
docker-compose up -d

# 6. Aguardar e verificar saúde
echo -e "${YELLOW}[6/6] Verificando saúde dos serviços...${NC}"
sleep 15

if docker-compose ps | grep -q "Up"; then
    echo -e "${GREEN}✅ ZIA TRADER v17 está rodando com sucesso!${NC}"
    echo ""
    echo "Serviços ativos:"
    docker-compose ps
    echo ""
    echo "Para ver logs em tempo real:"
    echo "  docker-compose logs -f zia-app"
    echo ""
    echo "Para parar tudo:"
    echo "  docker-compose down"
else
    echo -e "${RED}❌ Falha no deploy. Veja os logs:${NC}"
    docker-compose logs --tail=50
    exit 1
fi
