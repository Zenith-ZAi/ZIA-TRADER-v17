"""
agent/zia_agent.py

ZIA — Agente de Chat Trader ao Vivo
Integrado ao core do ZIA TRADER v17.

Arquitetura:
  - Recebe mensagem do usuário via WebSocket/HTTP
  - Consulta estado real do TradingManager (preços, posições, risco)
  - Usa Claude API (function calling) para raciocinar e responder
  - Executa ações reais: análise, simulação, alertas
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime

import httpx

from config.settings import Settings

logger = logging.getLogger(__name__)

# ─── Ferramentas que o Agente pode chamar ────────────────────────────────────

AGENT_TOOLS = [
    {
        "name": "get_market_status",
        "description": (
            "Retorna o preço atual, volume, variação 24h e sentimento de mercado "
            "de um ou mais ativos. Use sempre que o usuário perguntar sobre preço, "
            "tendência ou estado atual de um ativo."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "symbols": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Lista de símbolos. Ex: ['BTC/USDT', 'ETH/USDT']"
                }
            },
            "required": ["symbols"]
        }
    },
    {
        "name": "get_open_positions",
        "description": (
            "Retorna todas as posições abertas no momento: símbolo, lado (buy/sell), "
            "quantidade, preço de entrada, PnL atual e stop loss. "
            "Use quando o usuário perguntar sobre posições abertas ou operações ativas."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "get_recent_trades",
        "description": (
            "Retorna o histórico das últimas operações executadas pelo sistema: "
            "símbolo, ação, resultado (lucro/perda), horário e estratégia usada. "
            "Use para responder perguntas sobre performance recente."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "Quantidade de trades a retornar. Padrão: 10.",
                    "default": 10
                }
            },
            "required": []
        }
    },
    {
        "name": "get_risk_metrics",
        "description": (
            "Retorna as métricas de risco atuais: drawdown, exposição total, "
            "win rate, ratio risco/retorno e capital disponível. "
            "Use para perguntas sobre risco, saldo ou saúde da conta."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "analyze_symbol",
        "description": (
            "Executa análise técnica completa de um ativo: tendência, suporte/resistência, "
            "indicadores (RSI, MACD, Bollinger), padrões de vela e sugestão de entrada/saída. "
            "Use quando o usuário pedir análise, opinião ou setup de um ativo específico."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Símbolo do ativo. Ex: 'BTC/USDT'"
                },
                "timeframe": {
                    "type": "string",
                    "description": "Timeframe da análise. Ex: '1h', '4h', '1d'",
                    "default": "1h"
                }
            },
            "required": ["symbol"]
        }
    },
    {
        "name": "get_news_sentiment",
        "description": (
            "Retorna as últimas notícias relevantes e o score de sentimento agregado "
            "para um ativo ou o mercado geral. "
            "Use quando o usuário perguntar sobre notícias, fundamentos ou sentimento."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Símbolo ou termo de busca. Ex: 'BTC', 'crypto', 'mercado'"
                }
            },
            "required": ["symbol"]
        }
    },
    {
        "name": "simulate_order",
        "description": (
            "Simula uma ordem (sem executar de verdade) e retorna: validação de risco, "
            "tamanho ideal de posição, stop loss sugerido, take profit e RR ratio. "
            "Use quando o usuário quiser saber se uma entrada específica é viável."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "symbol":   {"type": "string", "description": "Ex: 'BTC/USDT'"},
                "action":   {"type": "string", "description": "'buy' ou 'sell'"},
                "price":    {"type": "number", "description": "Preço de entrada desejado"},
                "quantity": {"type": "number", "description": "Quantidade desejada"}
            },
            "required": ["symbol", "action", "price", "quantity"]
        }
    },
    {
        "name": "get_system_status",
        "description": (
            "Retorna o status operacional do sistema ZIA: motores ativos, "
            "última execução, conexão com exchanges e saúde geral. "
            "Use quando o usuário perguntar se o bot está rodando ou funcionando."
        ),
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": []
        }
    }
]

# ─── Sistema Prompt do Agente ─────────────────────────────────────────────────

SYSTEM_PROMPT = """Você é ZIA (Zenith Intelligence Agent), o assistente especialista de trading do sistema ZIA TRADER v17.

Você tem acesso em tempo real ao estado do sistema de trading: preços, posições abertas, histórico de operações, métricas de risco, análise técnica e sentimento de notícias.

## Sua personalidade:
- Direto, preciso e profissional como um trader experiente
- Explica conceitos complexos de forma simples quando necessário
- Nunca inventa dados — sempre consulta as ferramentas disponíveis
- Alerta sobre riscos sem hesitar
- Fala em português do Brasil

## Suas capacidades:
- Informar preços, tendências e status de mercado em tempo real
- Analisar ativos com indicadores técnicos completos
- Revisar posições abertas e PnL atual
- Simular ordens para validar estratégias antes de executar
- Interpretar notícias e sentimento do mercado
- Explicar decisões do algoritmo de trading

## Regras absolutas:
- Nunca execute ordens reais pelo chat — apenas simule e informe
- Sempre mencione o risco associado em qualquer sugestão de entrada
- Se não tiver dados suficientes, diga claramente em vez de especular
- Mantenha respostas objetivas: máximo 4 parágrafos salvo quando análise exigir mais

Data/hora atual: {datetime}
"""

# ─── Executor de Ferramentas ──────────────────────────────────────────────────

class AgentToolExecutor:
    """
    Executa as ferramentas chamadas pelo agente Claude.
    Conecta diretamente aos componentes do TradingManager.
    """

    def __init__(self, trading_manager=None, settings: Settings = None):
        self.trading_manager = trading_manager
        self.settings = settings

    async def execute(self, tool_name: str, tool_input: Dict[str, Any]) -> str:
        """Despacha a chamada para o método correto."""
        handlers = {
            "get_market_status":   self._get_market_status,
            "get_open_positions":  self._get_open_positions,
            "get_recent_trades":   self._get_recent_trades,
            "get_risk_metrics":    self._get_risk_metrics,
            "analyze_symbol":      self._analyze_symbol,
            "get_news_sentiment":  self._get_news_sentiment,
            "simulate_order":      self._simulate_order,
            "get_system_status":   self._get_system_status,
        }
        handler = handlers.get(tool_name)
        if not handler:
            return json.dumps({"error": f"Ferramenta desconhecida: {tool_name}"})
        try:
            return await handler(tool_input)
        except Exception as e:
            logger.error(f"Erro ao executar ferramenta {tool_name}: {e}")
            return json.dumps({"error": str(e)})

    async def _get_market_status(self, inp: Dict) -> str:
        symbols = inp.get("symbols", self.settings.SYMBOLS if self.settings else ["BTC/USDT"])
        result = {}
        if self.trading_manager:
            for sym in symbols:
                data = await self.trading_manager.exchange_connector.get_market_data(sym)
                result[sym] = data or {"error": "Dados indisponíveis"}
        else:
            # Modo demo quando TradingManager não está conectado
            for sym in symbols:
                result[sym] = {
                    "last": 67450.0, "change_24h": 2.3,
                    "volume": 18500.0, "high": 68100.0, "low": 66200.0,
                    "note": "dados demo — conecte o TradingManager para dados reais"
                }
        return json.dumps(result, default=str)

    async def _get_open_positions(self, inp: Dict) -> str:
        if self.trading_manager and hasattr(self.trading_manager, "execution_engine"):
            positions = getattr(self.trading_manager.execution_engine, "open_positions", {})
            return json.dumps(positions, default=str)
        return json.dumps({"positions": [], "note": "Nenhuma posição aberta no momento."})

    async def _get_recent_trades(self, inp: Dict) -> str:
        limit = inp.get("limit", 10)
        if self.trading_manager and hasattr(self.trading_manager, "execution_engine"):
            history = getattr(self.trading_manager.execution_engine, "trade_history", [])
            return json.dumps({"trades": history[-limit:], "total": len(history)}, default=str)
        return json.dumps({"trades": [], "note": "Histórico de trades ainda vazio ou motor não conectado."})

    async def _get_risk_metrics(self, inp: Dict) -> str:
        if self.trading_manager and hasattr(self.trading_manager, "execution_engine"):
            ee = self.trading_manager.execution_engine
            metrics = {
                "balance":      getattr(ee, "account_balance", 10000.0),
                "total_pnl":    getattr(ee, "total_pnl", 0.0),
                "win_rate":     getattr(ee, "win_rate", 0.0),
                "max_drawdown": getattr(ee, "max_drawdown", 0.0),
                "open_trades":  len(getattr(ee, "open_positions", {})),
                "max_risk_per_trade": f"{(self.settings.MAX_RISK_PER_TRADE * 100):.1f}%"
            }
            return json.dumps(metrics, default=str)
        return json.dumps({"note": "Motor de execução não conectado. Métricas indisponíveis."})

    async def _analyze_symbol(self, inp: Dict) -> str:
        symbol    = inp.get("symbol", "BTC/USDT")
        timeframe = inp.get("timeframe", "1h")
        if self.trading_manager:
            try:
                df = await self.trading_manager.exchange_connector.get_historical_data(
                    symbol, timeframe, limit=100
                )
                if df.empty:
                    return json.dumps({"error": "Sem dados históricos disponíveis."})

                close = df["close"]
                # Indicadores básicos calculados sem TA-Lib para segurança
                rsi_period = 14
                delta  = close.diff()
                gain   = delta.clip(lower=0).rolling(rsi_period).mean()
                loss   = (-delta.clip(upper=0)).rolling(rsi_period).mean()
                rs     = gain / loss
                rsi    = (100 - (100 / (1 + rs))).iloc[-1]

                ema9   = close.ewm(span=9).mean().iloc[-1]
                ema21  = close.ewm(span=21).mean().iloc[-1]
                ema50  = close.ewm(span=50).mean().iloc[-1]
                trend  = "ALTA" if ema9 > ema21 > ema50 else ("BAIXA" if ema9 < ema21 < ema50 else "LATERAL")

                last_price = float(close.iloc[-1])
                support    = float(df["low"].tail(20).min())
                resistance = float(df["high"].tail(20).max())

                analysis = {
                    "symbol":        symbol,
                    "timeframe":     timeframe,
                    "last_price":    round(last_price, 4),
                    "trend":         trend,
                    "rsi":           round(float(rsi), 2),
                    "rsi_signal":    "SOBRECOMPRADO" if rsi > 70 else ("SOBREVENDIDO" if rsi < 30 else "NEUTRO"),
                    "ema9":          round(float(ema9), 4),
                    "ema21":         round(float(ema21), 4),
                    "ema50":         round(float(ema50), 4),
                    "support":       round(support, 4),
                    "resistance":    round(resistance, 4),
                    "candles_analyzed": len(df),
                    "timestamp":     datetime.utcnow().isoformat()
                }
                return json.dumps(analysis)
            except Exception as e:
                return json.dumps({"error": f"Falha na análise: {str(e)}"})
        return json.dumps({"note": "TradingManager não conectado. Análise indisponível."})

    async def _get_news_sentiment(self, inp: Dict) -> str:
        symbol = inp.get("symbol", "crypto")
        if self.trading_manager and hasattr(self.trading_manager, "news_processor"):
            try:
                news = await self.trading_manager.news_processor.get_latest_news(symbol)
                return json.dumps(news, default=str)
            except Exception as e:
                return json.dumps({"error": str(e)})
        return json.dumps({
            "symbol": symbol,
            "sentiment_score": 0.0,
            "articles": [],
            "note": "NewsProcessor não conectado."
        })

    async def _simulate_order(self, inp: Dict) -> str:
        symbol   = inp.get("symbol", "BTC/USDT")
        action   = inp.get("action", "buy")
        price    = inp.get("price", 0.0)
        quantity = inp.get("quantity", 0.0)

        if self.trading_manager and hasattr(self.trading_manager, "trading_engine"):
            try:
                risk_ai      = self.trading_manager.trading_engine.risk_ai
                balance      = getattr(self.trading_manager.execution_engine, "account_balance", 10000.0)
                order_data   = {"symbol": symbol, "action": action,
                                "quantity": quantity, "confidence": 0.75}
                market_ctx   = {"news_impact": 0.1, "candle_pattern": "neutral",
                                "historical_data": __import__("pandas").DataFrame(),
                                "current_order_flow": {}}
                validation   = risk_ai.validate_order(order_data, balance, market_ctx)

                stop_pct  = 0.015  # 1.5%
                tp_pct    = 0.03   # 3.0%
                stop_loss = round(price * (1 - stop_pct) if action == "buy" else price * (1 + stop_pct), 4)
                take_profit = round(price * (1 + tp_pct) if action == "buy" else price * (1 - tp_pct), 4)
                position_value = round(price * quantity, 2)
                rr_ratio  = round(tp_pct / stop_pct, 2)

                return json.dumps({
                    "symbol":        symbol,
                    "action":        action,
                    "price":         price,
                    "quantity":      quantity,
                    "position_value_usd": position_value,
                    "stop_loss":     stop_loss,
                    "take_profit":   take_profit,
                    "rr_ratio":      f"1:{rr_ratio}",
                    "risk_validation": validation,
                    "mode":          "SIMULAÇÃO — ordem não enviada à exchange"
                })
            except Exception as e:
                return json.dumps({"error": str(e)})

        return json.dumps({
            "symbol": symbol, "action": action, "price": price, "quantity": quantity,
            "note": "Simulação sem TradingManager conectado."
        })

    async def _get_system_status(self, inp: Dict) -> str:
        if self.trading_manager:
            te = self.trading_manager.trading_engine
            status = {
                "trading_engine_running": getattr(te, "is_running", False),
                "symbols_monitored":      getattr(te, "symbols", []),
                "timeframe":              getattr(te, "timeframe", "N/A"),
                "exchange":               self.settings.CRYPTO_EXCHANGE if self.settings else "N/A",
                "timestamp":              datetime.utcnow().isoformat()
            }
        else:
            status = {
                "trading_engine_running": False,
                "note": "TradingManager não conectado ao agente.",
                "timestamp": datetime.utcnow().isoformat()
            }
        return json.dumps(status)


# ─── Agente Principal ─────────────────────────────────────────────────────────

class ZIAAgent:
    """
    Agente de Chat ZIA ao Vivo.
    Usa Claude API com function calling para responder em tempo real,
    consultando os dados reais do sistema de trading.
    """

    CLAUDE_MODEL   = "claude-sonnet-4-20250514"
    CLAUDE_API_URL = "https://api.anthropic.com/v1/messages"
    MAX_TOKENS     = 1500
    MAX_ITERATIONS = 5  # máximo de chamadas de ferramenta por turno

    def __init__(
        self,
        api_key: str,
        trading_manager=None,
        settings: Settings = None
    ):
        self.api_key  = api_key
        self.settings = settings
        self.executor = AgentToolExecutor(trading_manager, settings)
        self.conversation_history: List[Dict] = []

    def _build_system_prompt(self) -> str:
        return SYSTEM_PROMPT.format(
            datetime=datetime.utcnow().strftime("%d/%m/%Y %H:%M UTC")
        )

    async def _call_claude(self, messages: List[Dict]) -> Dict:
        """Chama a API do Claude com as mensagens e ferramentas."""
        headers = {
            "Content-Type":      "application/json",
            "x-api-key":         self.api_key,
            "anthropic-version": "2023-06-01"
        }
        payload = {
            "model":      self.CLAUDE_MODEL,
            "max_tokens": self.MAX_TOKENS,
            "system":     self._build_system_prompt(),
            "tools":      AGENT_TOOLS,
            "messages":   messages
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(self.CLAUDE_API_URL, headers=headers, json=payload)
            resp.raise_for_status()
            return resp.json()

    async def chat(self, user_message: str) -> str:
        """
        Processa uma mensagem do usuário e retorna a resposta do agente.
        Mantém histórico da conversa para contexto contínuo.
        """
        self.conversation_history.append({
            "role":    "user",
            "content": user_message
        })

        messages = self.conversation_history.copy()
        final_response = ""

        for iteration in range(self.MAX_ITERATIONS):
            try:
                response = await self._call_claude(messages)
            except httpx.HTTPStatusError as e:
                logger.error(f"Erro na API Claude: {e.response.text}")
                return "❌ Erro ao conectar com o modelo de IA. Tente novamente."
            except Exception as e:
                logger.error(f"Erro inesperado: {e}")
                return "❌ Erro interno do agente."

            stop_reason = response.get("stop_reason")
            content     = response.get("content", [])

            # Adiciona resposta ao histórico
            messages.append({"role": "assistant", "content": content})

            # Sem chamadas de ferramenta → resposta final
            if stop_reason == "end_turn":
                for block in content:
                    if block.get("type") == "text":
                        final_response = block["text"]
                break

            # Processa chamadas de ferramentas
            if stop_reason == "tool_use":
                tool_results = []
                for block in content:
                    if block.get("type") == "tool_use":
                        tool_id     = block["id"]
                        tool_name   = block["name"]
                        tool_input  = block.get("input", {})

                        logger.info(f"ZIA Agent chamando ferramenta: {tool_name}({tool_input})")
                        result_str  = await self.executor.execute(tool_name, tool_input)

                        tool_results.append({
                            "type":        "tool_result",
                            "tool_use_id": tool_id,
                            "content":     result_str
                        })

                # Adiciona resultados das ferramentas e continua o loop
                messages.append({"role": "user", "content": tool_results})
                continue

            # Qualquer outro stop_reason
            for block in content:
                if block.get("type") == "text":
                    final_response = block.get("text", "")
            break

        # Atualiza histórico oficial com a resposta final
        if final_response:
            self.conversation_history.append({
                "role":    "assistant",
                "content": final_response
            })

        # Limita histórico a 30 turnos para não exceder contexto
        if len(self.conversation_history) > 60:
            self.conversation_history = self.conversation_history[-60:]

        return final_response or "Não consegui gerar uma resposta. Tente reformular sua pergunta."

    def reset_conversation(self):
        """Reinicia o histórico da conversa."""
        self.conversation_history = []
        logger.info("Histórico do agente ZIA reiniciado.")
