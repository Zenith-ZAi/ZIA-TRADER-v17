"""
agent/chat_router.py

Rotas FastAPI para o Agente ZIA:
  - POST /agent/chat         — mensagem simples (HTTP)
  - WebSocket /agent/ws      — chat em tempo real
  - POST /agent/reset        — limpar histórico
  - GET  /agent/status       — saúde do agente
"""

import logging
from typing import Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException
from pydantic import BaseModel

from agent.zia_agent import ZIAAgent

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/agent", tags=["ZIA Agent"])

# ─── Schemas ─────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = "default"

class ChatResponse(BaseModel):
    response:   str
    session_id: str
    model:      str = "claude-sonnet-4-20250514"

# ─── Gerenciador de Sessões ───────────────────────────────────────────────────

class AgentSessionManager:
    """
    Mantém instâncias de ZIAAgent separadas por session_id.
    Cada usuário tem seu próprio histórico de conversa.
    """
    def __init__(self):
        self._sessions: dict = {}

    def get_or_create(self, session_id: str, api_key: str, trading_manager=None, settings=None) -> ZIAAgent:
        if session_id not in self._sessions:
            self._sessions[session_id] = ZIAAgent(
                api_key=api_key,
                trading_manager=trading_manager,
                settings=settings
            )
            logger.info(f"Nova sessão do agente criada: {session_id}")
        return self._sessions[session_id]

    def reset(self, session_id: str):
        if session_id in self._sessions:
            self._sessions[session_id].reset_conversation()

    def remove(self, session_id: str):
        self._sessions.pop(session_id, None)


session_manager = AgentSessionManager()

# ─── Dependency: obtém o agente para uma sessão ───────────────────────────────

def get_agent_for_session(session_id: str = "default") -> ZIAAgent:
    """
    Dependency injection do FastAPI.
    Na inicialização real, injete trading_manager e settings via lifespan.
    """
    from config.settings import settings as app_settings
    import os

    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY não configurada.")

    # trading_manager será injetado via app.state após inicialização
    trading_manager = None
    return session_manager.get_or_create(session_id, api_key, trading_manager, app_settings)


# ─── Rotas HTTP ───────────────────────────────────────────────────────────────

@router.post("/chat", response_model=ChatResponse)
async def chat_http(request: ChatRequest):
    """
    Endpoint HTTP simples para chat com o agente ZIA.
    Ideal para integração com frontend via fetch/axios.
    """
    agent = get_agent_for_session(request.session_id)
    response_text = await agent.chat(request.message)
    return ChatResponse(
        response=response_text,
        session_id=request.session_id
    )


@router.post("/reset")
async def reset_session(session_id: str = "default"):
    """Reinicia o histórico de conversa de uma sessão."""
    session_manager.reset(session_id)
    return {"status": "ok", "message": f"Sessão '{session_id}' reiniciada."}


@router.get("/status")
async def agent_status():
    """Verifica se o agente está operacional."""
    import os
    has_key = bool(os.getenv("ANTHROPIC_API_KEY"))
    return {
        "status":    "online" if has_key else "sem_chave_api",
        "model":     ZIAAgent.CLAUDE_MODEL,
        "sessions":  len(session_manager._sessions),
        "ready":     has_key
    }


# ─── WebSocket — Chat em Tempo Real ──────────────────────────────────────────

@router.websocket("/ws/{session_id}")
async def chat_websocket(websocket: WebSocket, session_id: str):
    """
    WebSocket para chat ao vivo com o agente ZIA.
    
    Protocolo de mensagens (JSON):
      Cliente → Servidor: {"message": "Qual o preço do BTC?"}
      Servidor → Cliente: {"type": "response",  "text": "...", "session_id": "..."}
      Servidor → Cliente: {"type": "error",     "text": "..."}
      Servidor → Cliente: {"type": "thinking",  "text": "Consultando mercado..."}
    """
    await websocket.accept()
    logger.info(f"WebSocket conectado: sessão {session_id}")

    import os
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        await websocket.send_json({
            "type": "error",
            "text": "ANTHROPIC_API_KEY não configurada no servidor."
        })
        await websocket.close()
        return

    from config.settings import settings as app_settings
    agent = session_manager.get_or_create(session_id, api_key, None, app_settings)

    # Mensagem de boas-vindas
    await websocket.send_json({
        "type": "connected",
        "text": (
            "✅ ZIA Agent conectado. Olá! Sou a ZIA, sua assistente de trading ao vivo. "
            "Posso analisar ativos, verificar posições, consultar notícias e simular ordens. "
            "Como posso ajudar?"
        ),
        "session_id": session_id
    })

    try:
        while True:
            raw = await websocket.receive_text()

            try:
                data    = __import__("json").loads(raw)
                message = data.get("message", "").strip()
            except Exception:
                message = raw.strip()

            if not message:
                continue

            # Notifica que está processando
            await websocket.send_json({
                "type": "thinking",
                "text": "⏳ Consultando dados do mercado..."
            })

            # Processa e responde
            response = await agent.chat(message)

            await websocket.send_json({
                "type":       "response",
                "text":       response,
                "session_id": session_id
            })

    except WebSocketDisconnect:
        logger.info(f"WebSocket desconectado: sessão {session_id}")
    except Exception as e:
        logger.error(f"Erro no WebSocket {session_id}: {e}")
        try:
            await websocket.send_json({"type": "error", "text": f"Erro interno: {str(e)}"})
        except Exception:
            pass
