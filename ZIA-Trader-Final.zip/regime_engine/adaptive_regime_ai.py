class AdaptiveRegimeAI:
    def detect_regime(self, market):
        return "trend"