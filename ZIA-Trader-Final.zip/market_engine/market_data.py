class MarketData:
    def fetch(self):
        return {
            "btc":1,
            "sp500":1,
            "dxy":-1,
            "liquidity":0.6,
            "volatility":0.5,
            "sentiment":0.55
        }