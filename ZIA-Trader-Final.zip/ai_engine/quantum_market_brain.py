class QuantumMarketBrain:

    def analyze_macro(self, markets):
        score = 0
        if markets.get("dxy",0) > 0: score += 1
        if markets.get("sp500",0) > 0: score += 1
        if markets.get("btc",0) > 0: score += 1
        return score / 3

    def calculate_brain_score(self, macro, liquidity, volatility, sentiment):
        return (macro + liquidity + volatility + sentiment) / 4