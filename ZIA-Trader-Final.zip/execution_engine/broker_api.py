class BrokerAPI:
    def execute(self, mode):
        print(f"Executing trade in {mode} mode")