# ZIA Trader

Institutional AI Trading System

Features:
- Quantum Market Brain
- Adaptive Regime AI
- Modular Trading Engine

Run:
python main.py