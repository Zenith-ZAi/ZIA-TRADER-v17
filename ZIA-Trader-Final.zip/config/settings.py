class Settings:
    APP_NAME = "ZIA Trader"