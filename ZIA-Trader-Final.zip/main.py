from core.trading_engine import TradingEngine
from market_engine.market_data import MarketData
from ai_engine.ai_model import AIModel
from ai_engine.quantum_market_brain import QuantumMarketBrain
from regime_engine.adaptive_regime_ai import AdaptiveRegimeAI
from risk_engine.risk_manager import RiskManager
from execution_engine.broker_api import BrokerAPI

market = MarketData()
ai = AIModel()
regime = AdaptiveRegimeAI()
risk = RiskManager()
broker = BrokerAPI()
quantum = QuantumMarketBrain()

engine = TradingEngine(market, ai, regime, risk, broker, quantum)
engine.run_cycle()