class TradingEngine:
    def __init__(self, market_engine, ai_engine, regime_engine, risk_engine, execution_engine, quantum_brain):
        self.market_engine = market_engine
        self.ai_engine = ai_engine
        self.regime_engine = regime_engine
        self.risk_engine = risk_engine
        self.execution_engine = execution_engine
        self.quantum_brain = quantum_brain

    def run_cycle(self):
        market_data = self.market_engine.fetch()
        regime = self.regime_engine.detect_regime(market_data)
        prediction = self.ai_engine.predict(market_data)

        macro = self.quantum_brain.analyze_macro(market_data)
        score = self.quantum_brain.calculate_brain_score(
            macro,
            market_data.get("liquidity",0.5),
            market_data.get("volatility",0.5),
            market_data.get("sentiment",0.5)
        )

        confidence = 0.7 * prediction + 0.3 * score

        if self.risk_engine.validate(confidence):
            self.execution_engine.execute("auto")