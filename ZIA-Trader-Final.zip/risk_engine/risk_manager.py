class RiskManager:
    def validate(self, confidence):
        return confidence > 0.6